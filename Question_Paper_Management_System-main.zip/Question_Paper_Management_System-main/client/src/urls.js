export const LOGIN_URL = 'http://localhost:3000/api/user/login'
export const SIGNUP_URL = 'http://localhost:3000/api/user/signup'
export const USERDETAILS_URL = 'http://localhost:3000/api/user/get'