module.exports.userController = require('./user.controller');
module.exports.imageController = require('./image.controller');
module.exports.examController = require('./exam.controller');